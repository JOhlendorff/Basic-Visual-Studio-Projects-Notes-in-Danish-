﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nedarvning_Opgave
{
    class Furniture
    {
        protected string producent;
        protected int pris;
        public void SetProducent(string producent)
        {
        this.producent = producent;
        }
        public string GetProducent()
        {
            return producent;
        }
        public void SetPris(int pris)
        {
            this.pris = pris;
        }
        public int GetPris()
        {
            return pris;
        }
        public void PrintInfo()
        {
            Console.WriteLine("Producent: "+producent+" pris: "+ pris);
        }
    }
}
