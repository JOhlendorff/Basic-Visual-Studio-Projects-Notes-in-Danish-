﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nedarvning_Opgave
{
    class Chair : Furniture
    {
        protected int antalBen;
        public void SetAntalBen(int antalBen)
        {
        this.antalBen = antalBen;
        }
        public int GetAntalBen()
        {
            return antalBen;
        }
        public void PrintInfo()
        {
            Console.WriteLine("Producent: " + producent + " pris: " + pris+" antal ben: "+ antalBen);
        }
    }
}
