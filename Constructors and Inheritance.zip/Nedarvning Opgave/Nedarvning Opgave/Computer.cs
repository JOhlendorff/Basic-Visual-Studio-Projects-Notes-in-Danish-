﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nedarvning_Opgave
{
    class Computer : Furniture
    {
        protected string grafik;
        public void SetGrafik(string grafik)
        {
            this.grafik = grafik;
        }
        public string GetGrafik()
        {
            return grafik;
        }
        public void PrintInfo()
        {
            Console.WriteLine("Producent: " + producent + " pris: " + pris+" grafik: "+grafik);
        }
    }
}
