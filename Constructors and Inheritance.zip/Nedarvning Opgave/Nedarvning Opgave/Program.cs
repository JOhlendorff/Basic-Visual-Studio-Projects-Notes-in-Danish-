﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nedarvning_Opgave
{
    class Program
    {
        static void Main(string[] args)
        {
            Furniture bord = new Furniture();
            bord.SetPris(11);
            bord.SetProducent("bordfabrikken");
            bord.PrintInfo();
            Chair stol = new Chair();
            stol.SetPris(25);
            stol.SetProducent("Stolfabrikken");
            stol.SetAntalBen(16);
            stol.PrintInfo();
            Computer pc = new Computer();
            pc.SetPris(99);
            pc.SetProducent("Computerfabrikken");
            pc.SetGrafik("NVidia GTX 1080");
            pc.PrintInfo();
            Console.ReadKey();

        }
    }
}
