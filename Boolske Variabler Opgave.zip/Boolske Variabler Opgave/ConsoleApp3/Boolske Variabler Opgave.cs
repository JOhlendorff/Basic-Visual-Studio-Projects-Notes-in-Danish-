﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {

            int var1 = 1, var2 = 2;
            bool Bool = var1 > var2; //Denne boolean tjekker om udtrykket er sandt. I dette tilfælde er det falsk fordi 1 ikke er større end 2
            Console.WriteLine("{0}", Bool);
            Console.ReadKey();
        }
    }
}
