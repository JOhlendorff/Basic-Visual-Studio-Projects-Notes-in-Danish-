﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lommeregner_Konsol
{
    class Regnestykke
    {
        protected double tal1;
        protected double tal2;
        protected string fortegn;
        public Regnestykke(double tal1, double tal2, string fortegn)
        {
            this.tal1 = tal1;
            this.tal2 = tal2;
            this.fortegn = fortegn;
        }
        public double Udregn()
        {
            switch (fortegn)
            {
                case "+":
                    return tal1 + tal2;
                case "-":
                    return tal1 - tal2;
                case "*":
                    return tal1 * tal2;
                case "/":
                    return tal1 / tal2; 
            }
            return 0;
        }
        public double Plus2()
        {
            return tal1 += 2;
        }
        public void PrintInfoPlus2()
        {
            Console.Clear();
            Console.WriteLine(tal1);
        }
    }
}
