﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lommeregner_Konsol
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Indtast tal1, så et fortegn og så tal2");
            double tal1 = Convert.ToDouble(Console.ReadLine());
            string fortegn = Console.ReadLine();
            double tal2 = Convert.ToDouble(Console.ReadLine());

            Regnestykke plus2 = new Regnestykke(tal1, tal2, fortegn);
            //plus2.Plus2();
            //plus2.PrintInfoPlus2();
            Console.WriteLine(plus2.Udregn());
            Console.ReadKey();
        }
    }
}
