﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lommeregner_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        

        private void Button1_Click(object sender, EventArgs e)//Denne metode gør at når man trykker på knappen i applikationen bliver regnestykket udregnet
        {//
            //double result;
            double regnestykkeTal1;
            double regnestykkeTal2;
            string regnestykke = textBox1.Text;
            if (regnestykke!=string.Empty)
            {
                //string regnestykke = textBox1.Text;
                string[] separators = { "+", "-", "*", "/" };//Det her array indeholder de tegn der fjernes fra teksten brugeren har skrevet 
                string[] regnestykkeSep = regnestykke.Split(separators, StringSplitOptions.RemoveEmptyEntries);//Bruger separators arrayet til at adksille 
                if (regnestykkeSep[0] != string.Empty && regnestykkeSep[1] != string.Empty)//Her tjekker jeg om arrayet jeg har lavet indeholder noget, hvis de gør køres udregningen, hvis ikke kommer der en error tekst
                {
                    regnestykkeTal1 = Convert.ToDouble(regnestykkeSep[0]);//Eftersom arrayet stadig indeholder strings konverterer jeg dem til doubles
                    regnestykkeTal2 = Convert.ToDouble(regnestykkeSep[1]);

                    double result;//Denne variabel indeholder resultatet fra udregningen. Det er en double fordi den skal kunne dividere, derfor kan der være behov for decimaler
                    if (regnestykke.Contains("+"))//Hvis regnestykket indeholder "+" lægges de to tal sammen
                    {
                        result = regnestykkeTal1 + regnestykkeTal2;
                        string resultS = Convert.ToString(result);//Jeg konverterer result doublen til at være en string fordi textboksen, sjovt nok, indeholder tekst så det skal være en string
                        textBox1.Text = resultS;//Dette ændrer teksten i tekstboksen til at være resultatet
                    }
                    else if (regnestykke.Contains("-"))
                    {
                        result = regnestykkeTal1 - regnestykkeTal2;
                        string resultS = Convert.ToString(result);
                        textBox1.Text = resultS;
                    }
                    else if (regnestykke.Contains("*"))
                    {
                        result = regnestykkeTal1 * regnestykkeTal2;
                        string resultS = Convert.ToString(result);
                        textBox1.Text = resultS;
                    }
                    else if (regnestykke.Contains("/"))
                    {
                        result = regnestykkeTal1 / regnestykkeTal2;
                        string resultS = Convert.ToString(result);
                        textBox1.Text = resultS;
                    }
                }
                else
                {
                    MessageBox.Show("Ugyldige tal/operator");
                }
            }
            else
            {
                MessageBox.Show("Tekst tom");
            }
            
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        
    }
}
