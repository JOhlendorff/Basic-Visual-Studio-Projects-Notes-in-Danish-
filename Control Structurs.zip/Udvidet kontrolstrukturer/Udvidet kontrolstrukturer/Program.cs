﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Udvidet_kontrolstrukturer
{
    class Program
    {
        static void Main(string[] args)
        {for(int result = 3; result > 0; result = result +3)// så længe result er større end 0 bliver 3 lagt til result = infinite loop.
            {
                Console.WriteLine(result);
                if(result ==21)// Eftersom opgaven sagde man skulle lave en if sætning har jeg gjort det istedet i for loopen. om det giver mening eller ej :^)
                {
                    break;// loopen stopper her
                }
            }
            Console.WriteLine("Loopen er nu stoppet");
            Console.ReadKey();
        }
    }
}
