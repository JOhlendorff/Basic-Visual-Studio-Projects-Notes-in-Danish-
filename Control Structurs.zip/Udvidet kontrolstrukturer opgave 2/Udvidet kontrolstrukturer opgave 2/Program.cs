﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Udvidet_kontrolstrukturer_opgave_2
{
    class Program
    {
        static void Main(string[] args)
        {

            int result = 4;
            while(result <=40)
            {
                result = result + 4;
                Console.WriteLine(result);
                if (result == 12)// 16 springes over ved at der lægges 4 til før udskrivningen
                {
                    result = result + 4;
                }
            }
            Console.ReadKey();
        }
        
        
    }
}
