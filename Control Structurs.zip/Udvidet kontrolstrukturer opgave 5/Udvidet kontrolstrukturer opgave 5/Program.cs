﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Udvidet_kontrolstrukturer_opgave_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Indtast saldo");
            string inputf = Console.ReadLine();
            double input = Convert.ToDouble(inputf);//Jeg laver en to double her fordi jeg også bruger denne double til svaret, som i divisionsstykker ofte bliver decimaler
            if(input < 25000)
            {
                input = 0.0025 * input;
            }
            else if (input >= 25000 && input<150000)
            {
                input = 0.0125 * input;
            }
            else
            {
                input = (150000 * 0.0125) + (input - 150000) * 0.05;
            }
            input = System.Math.Round(input, 2);// dette runder tallet til at have 2 decimaler

            Console.WriteLine(input);
            Console.ReadKey();
        }
    }
}
