﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Udvidet_kontrolstrukturer_opgave_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Indtast din indkomst");
            string inputf = Console.ReadLine();
            double input = Convert.ToDouble(inputf);
            double skat = 0;
            if(input <42000)
            {
                Console.WriteLine("Der betales ingen skat, din skat er {0}", skat);
            }
            else if(input >= 42000 && input <280000)
            {
                input = (input - 42000) * 0.30;
                Console.WriteLine("Du betaler bundskat, {0} kr", input);
            }
            else if(input >= 280000 && input <390000)
            {
                skat = input * 0.36;
                Console.WriteLine("Du betaler mellemskat, {0} kr", skat);
            }
            else
            {
                skat = input * 0.51;
                Console.WriteLine("Du betaler topskat, {0} kr", skat);
            }
            Console.ReadKey();
        }
    }
}
