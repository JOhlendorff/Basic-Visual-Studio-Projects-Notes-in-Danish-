﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Udvidet_kontrolstrukturer_opgave_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputf;
            int input;
            Console.WriteLine("indtast kørte km");
            inputf = Console.ReadLine();
            input = Convert.ToInt32(inputf);
            if (input <=24)
            {
                input = 0;
            }
            else if(input >=25 && input <= 100)// hvis input er over 25 og under 100
            {
                input = input * 154;
            }
            else
            {
                input = (100 * 154) + (input - 100) * 77;// Har opstillet denne formel så det er 77 af sidst kørte km der trækkes fra hvis afstanden er over 100 km
            }
            Console.WriteLine("Dit befordringsfradrag er: {0} ører", input);
            Console.ReadKey();
        }
    }
}
