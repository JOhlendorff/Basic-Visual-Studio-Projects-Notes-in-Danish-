﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loops_Opgave_6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Indtast tal til tabel");
            string valg = Console.ReadLine();
            int tæller = 1, result = Convert.ToInt32(valg);
            for(int ValgC = Convert.ToInt32(valg); result <= ValgC*10; result = ValgC * tæller)//Det tog lidt tid før jeg fandt ud af at ValgC = ValgC + ValgC gav et eksponentielt voksende resultat, så jeg lavede en ny int der hed result. Dette løste problemet eftersom det gav det forrige tal + valget, hvilket er hvordan en tabel ser ud
            {//Jeg ville også begrænse antallet af numre til 10, så jeg sagde at så længe resultatet er under valgc * 10 skulle loopen udføres
                tæller++;// Tælleren bruger jeg til at gange med valgC, men kunne også gøres med ValgC = ValgC + ValgC
                ValgC = ValgC * 1;
                Console.WriteLine(result);
            }
            Console.ReadKey();
        }
    }
}
