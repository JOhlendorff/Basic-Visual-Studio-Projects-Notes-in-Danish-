﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loops_opgave_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //for (int Num = 1; Num <= 100; Num++) // Denne loop udskriver alle numre op til 100 og stopper så
            //{
            //   Console.WriteLine(Num);// Denne writeline udskriver nummeret der forøges
            //}

            int Num = 1;
            while(Num >= 100)// I en while loop skal variablen være defineret før 
            {
                Console.WriteLine(Num++);// I en while loop skal man skrive funktionerne imellem curly brackets. I for loopen var der en incrementering i loop dens for deklaration
            }
            
            Console.ReadKey();
        }
    }
}
