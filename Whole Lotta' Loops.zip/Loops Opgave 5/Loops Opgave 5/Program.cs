﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loops_Opgave_5
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int Numb1 = 7; Numb1 <= 70; Numb1 = Numb1 + 7)// Så længe numb er under eller lig 70 bliver 7 lagt til, hvilket giver 7 tabellen
            {
                int Count =1;
                Console.WriteLine("{0}*7={1}",Count, Numb1);
                Count++;//Denne tæller op hver gang loopen gentager, så der kommer til at stå 2 næste loop
            }
            int Numb2 = 7;
            while(Numb2 <= 70)
            {
                int Count = 1;
                Console.WriteLine("{0}*7={1}",Count, Numb2);
                Numb2 = Numb2 + 7;
            }
            Console.ReadKey();
        }
    }
}
