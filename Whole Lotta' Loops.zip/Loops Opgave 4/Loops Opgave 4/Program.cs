﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loops_Opgave_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int Num1 = 20;
            while(Num1 >=0)
            {
                Console.WriteLine(Num1--);//Så længe Num1 er større end eller lig 0 udskrives linjen. Derfor tæller den ned fra 20 til og med 0
            }
            for(int Num2 = 20; Num2 >=0; Num2--)
            {
                Console.WriteLine(Num2);
            }
            Console.ReadKey();
        }
    }
}
