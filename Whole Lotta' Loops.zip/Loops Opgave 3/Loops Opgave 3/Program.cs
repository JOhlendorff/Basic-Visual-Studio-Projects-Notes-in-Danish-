﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loops_Opgave_3
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int Num = 5; Num <= 50; Num = Num +5)//5 bliver lag til Num så længe Num er under 50
            {
                Console.WriteLine(Num);
            }
            Console.ReadKey();
        }
    }
}
