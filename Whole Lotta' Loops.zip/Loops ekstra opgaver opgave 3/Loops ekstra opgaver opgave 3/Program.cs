﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loops_ekstra_opgaver_opgave_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int X1, X12, Y12, Y1, X2, X22, Y2, Y22;// Der er lavet 2 slutkoordinater for hver fordi der trækkes fra den ene når jeg laver loopen
            string x1, y1, x2, y2, navn;// Der er lavet strings til at konvertere
            Console.WriteLine("Hvad hedder du");
            navn = Console.ReadLine();
            Console.WriteLine("Indtast start x");
            x1 = Console.ReadLine();
            X1 = Convert.ToInt32(x1);
            X12 = Convert.ToInt32(x1);
            Console.WriteLine("Indtast start y");
            y1 = Console.ReadLine();
            Y1 = Convert.ToInt32(y1);
            Y12 = Convert.ToInt32(y1);
            Console.WriteLine("Indtast slut x");
            x2 = Console.ReadLine();
            X2 = Convert.ToInt32(x2);
            X22 = Convert.ToInt32(x2);
            Console.WriteLine("indtast slut y");
            y2 = Console.ReadLine();
            Y2 = Convert.ToInt32(y2);
            Y22 = Convert.ToInt32(y2);
            Console.Clear();
            for (;X2 >= 0; X2--)//Slutkoordinaterne bliver mindsket så stregen går fra højre til venstre
            {
                Console.SetCursorPosition(X2,Y1);
                Console.WriteLine("▓");
            }
            for(;Y2 >=0; Y2--)
            {
                Console.SetCursorPosition(X1, Y2);
                Console.WriteLine("▓");
            }
            for(;X1 <= X22; X1++)// slutkoordinaterne bliver forhøjede så stregen går til højre
            {
                Console.SetCursorPosition(X1, Y22);
                Console.WriteLine("▓");
            }
            for (; Y1 <= Y22; Y1++)
            {
                Console.SetCursorPosition(X22, Y1);
                Console.WriteLine("▓");
            }
            Console.SetCursorPosition(X22/2, Y22/2);
            Console.WriteLine(navn);
            Console.ReadKey();

        }
    }
}
