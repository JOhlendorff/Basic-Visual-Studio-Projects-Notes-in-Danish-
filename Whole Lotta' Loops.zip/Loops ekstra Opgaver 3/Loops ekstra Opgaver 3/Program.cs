﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loops_ekstra_Opgaver_3
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Indtast koordinat start x");
            string Xstf = Console.ReadLine();
            Console.WriteLine("Indtast koordinat slut x");
            string Xslf = Console.ReadLine();
            Console.WriteLine("Indtast koordinat start y");
            string Ystf = Console.ReadLine();
            Console.WriteLine("Indtast koordinat slut y");
            string Yslf = Console.ReadLine();
            int XstfC = Convert.ToInt32(Xstf), XslfC = Convert.ToInt32(Xslf), YstfC = Convert.ToInt32(Ystf), YslfC = Convert.ToInt32(Yslf);
            Console.WriteLine("Indtast dit navn");
            string navn = Console.ReadLine();
            Console.Clear();

            for (YstfC = Convert.ToInt32(Ystf), YslfC = Convert.ToInt32(Yslf);YstfC <= YslfC; YstfC++)
            {
                Console.SetCursorPosition(0, YstfC);// Denne for loop udskriver ▓ på y's plads som rykker sig længere nedad
                Console.WriteLine("▓");

            }
            for (XstfC = Convert.ToInt32(Xstf), XslfC = Convert.ToInt32(Xslf); XstfC <= XslfC; XstfC++)//Denne for loop udskriver ▓ på X og y's plads som rykker sig længere nedad i konsollen
            {
                Console.SetCursorPosition(XstfC, 0);
                Console.WriteLine("▓");
            }
            for (XslfC = Convert.ToInt32(Xslf), XstfC = Convert.ToInt32(Xstf), YstfC = Convert.ToInt32(Ystf), YslfC = Convert.ToInt32(Yslf); XslfC >= XstfC; XslfC--)//Denne for loop udskriver ▓ på X og Y's plads som rykker sig længere opad i konsollen
            {
                Console.SetCursorPosition(XslfC, YslfC);
                Console.WriteLine("▓");
            }
            for (XslfC = Convert.ToInt32(Xslf), XstfC = Convert.ToInt32(Xstf), YstfC = Convert.ToInt32(Ystf), YslfC = Convert.ToInt32(Yslf); YslfC >= YstfC; YslfC--)//Denne for loop udskriver ▓ på X og Y's plads som rykker sig længere tilbage i konsollen
            {
                Console.SetCursorPosition(XslfC, YslfC);
                Console.WriteLine("▓");
            }

            Console.SetCursorPosition(XslfC, YslfC);
            Console.WriteLine(navn);
            Console.ReadKey();
            
        }
    }
}
