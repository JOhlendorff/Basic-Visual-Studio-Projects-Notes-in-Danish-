﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loops_Ekstra_Opgaver_2
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int X = 20, Y = 4; X <= 30; X++)
            {
                Console.SetCursorPosition(X, Y);// Denne for loop udskriver ▓ på X og y's plads som rykker sig længere fremad i konsollen
                Console.WriteLine("▓");

            }
            for (int X = 20, Y = 4; Y <= 8; Y++)//Denne for loop udskriver ▓ på X og y's plads som rykker sig længere nedad i konsollen
            {
                Console.SetCursorPosition(X, Y);
                Console.WriteLine("▓");
            }
            for (int X = 30, Y = 8; Y >= 4; Y--)//Denne for loop udskriver ▓ på X og Y's plads som rykker sig længere opad i konsollen
            {
                Console.SetCursorPosition(X, Y);
                Console.WriteLine("▓");
            }
            for (int X = 30, Y = 8; X >= 20; X--)//Denne for loop udskriver ▓ på X og Y's plads som rykker sig længere tilbage i konsollen
            {
                Console.SetCursorPosition(X, Y);
                Console.WriteLine("▓");
            }
            Console.SetCursorPosition(24,6);
            Console.WriteLine("jens");// mit navn :^)
            Console.ReadKey();
        }
    }
}
