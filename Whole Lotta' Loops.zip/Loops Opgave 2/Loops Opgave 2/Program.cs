﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loops_Opgave_2
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int Num = 100; Num >= 1; Num--) // Så længe Num er større end eller lig med 1 bliver der trukket 1 fra og udskrevet
            {
                Console.WriteLine(Num);// Denne writeline udskriver nummeret der formindskes
            }

            int Tal = 100;// I denne opgave skal der tælles ned, derfor ændrer jeg tælleren til 100.
            while (Tal >= 1)// Så længe nummer er større end eller lig med 1 udskrives det, og bliver formindsket
            {
                Console.WriteLine(Tal--); //Så længe Tal er større end eller lig med 1 bliver dette udskrevet
            }

            Console.ReadKey();
        }
    }
}
