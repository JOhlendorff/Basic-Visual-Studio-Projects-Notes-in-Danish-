﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace loops_ekstra_opgaver_3_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Indtast slut koordinat x");
            string Xf = Console.ReadLine();
            int X = Convert.ToInt32(Xf);
            Console.WriteLine("Indtast slut koordinat y");
            string Yf = Console.ReadLine();
            int Y = Convert.ToInt32(Yf);
            Console.WriteLine("Indtast navn");
            string navn = Console.ReadLine();
            Console.Clear();
            int start = 0;
            for(; X >=0; X--)
            {
                Console.SetCursorPosition(X, Y);
                Console.WriteLine("▓");
            }
            for(; Y >= 0; Y--)
            {
                Console.SetCursorPosition(X, Y);
                Console.WriteLine("▓");
            }
            for(; start <= X; start++)
            {
                Console.SetCursorPosition(start, Y);
                Console.WriteLine("▓");
            }
            for (; start <= Y; start++)
            {
                Console.SetCursorPosition(X, start);
                Console.WriteLine("▓");
            }

            Console.ReadKey();
        }
    }
}
