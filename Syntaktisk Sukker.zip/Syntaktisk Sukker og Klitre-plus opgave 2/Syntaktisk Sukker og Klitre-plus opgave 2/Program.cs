﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Syntaktisk_Sukker_og_Klitre_plus_opgave_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int Tæller1=0, Tæller2=0;
            Console.WriteLine("{0}{1}", ++Tæller1, Tæller2++); //Den ene console writeline preincrementerer og den anden postincremeneterer
            Console.WriteLine("{0}{1}", ++Tæller1, Tæller2++);// Forskellen på de to er at den ene tilføjer 1 til variablen før funktionen
            Console.WriteLine("{0}{1}", ++Tæller1, Tæller2++);//Tallene starter derfor fra 0 på postinkrementationen og fra 1 på preinkrementationen
            Console.WriteLine("{0}{1}", ++Tæller1, Tæller2++);
            Console.WriteLine("{0}{1}", ++Tæller1, Tæller2++);
            Console.ReadKey();
        }
    }
}
