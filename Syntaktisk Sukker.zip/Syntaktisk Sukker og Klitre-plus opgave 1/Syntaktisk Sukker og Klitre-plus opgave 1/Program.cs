﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Syntaktisk_Sukker_og_Klitre_plus_opgave_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int Tæller = 0;// Denne opgave viser hvordan man kan tælle op fra 0 med en incrementering. Eftersom jeg laver en postincrement kommer +1 først på næste linje, fordi 1 lægges til efter
            Console.WriteLine(Tæller++);
            Console.WriteLine(Tæller++);
            Console.WriteLine(Tæller++);
            Console.WriteLine(Tæller++);
            Console.WriteLine(Tæller++);
            Console.WriteLine(Tæller++);
            Console.ReadKey();
        }
    }
}
