﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Returtyper_og_Parameter___Opgave_1_og_2
{
    class Bil//Har lavet Bil klassen i en klasse over program
    {
        public void MotoStart()//Denne metode kaldes i program og udskriver "motoren er startet"
        {
            Console.WriteLine("Motoren er startet");
        }
        public void MotorSluk()
        {
            Console.WriteLine("Motoren er slukket");
        }
        public void FillGas(double liters, bool isDiesel)
        {

            Console.Write("Filled tank with" + liters +" liters of"/*+ isDiesel*/);// opgaven bad først om at få udskrevet true/false
            if (isDiesel == true)
            {
                Console.WriteLine(" Diesel");//Dette udskrives lige efter den forrige cw, fordi det var en console write, og dette er en writeline, så der er ikke en linje imellem
            }
            else
            {
                Console.WriteLine(" Gas");
            }
        }
        public double RemainingGas()
        {
            Console.WriteLine(7.5);
            return 7.5;//eftersom jeg vil have udskriften sætter jeg return efter cw, da return lukker programmet
            
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Bil skoda = new Bil();
            double liters = 2.5;
            skoda.MotoStart();
            skoda.MotorSluk();
            skoda.FillGas(liters, false);
            /*double x = */skoda.RemainingGas();
            /*Console.WriteLine(x);*/
            Console.ReadKey();

        }
    }
}
