﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bøger_2
{
    class Bog
    {
        private int pris;
        private string title;
        public Bog (int pris): this(pris, "Ikke sat")//Eftersom denne konstruktor skal kalde på den næste har jeg ladet titel stå til "ikke sat", fordi denne konstruktor ikke henter noget string input
        {
            this.pris = pris;//this. specificerer at det er integralet fra denne class der bruges
        }
        public Bog (int pris, string title)
        {
            this.pris = pris;
            this.title = title;
        }
        /*
        public void SetPris(int pris);//Man beder objektet om en variabel i "set" metoder
        {
        this.pris = pris
        }
        public int GetPris()
        {
            return pris;// metoder der har en variabel i navnet skal altid have en return
        }
        */
        public void SetTitle(string title)
        {
            this.title = title;
        }
        public string GetTitle()
        {
            return title;
        }
        public void PrintInfo2()
        {
            Console.WriteLine("Bog: " + title + " koster: " + pris);
        }
        /*
        public void PrintInfo()
        {
            Console.WriteLine("Jeg er en bog");
        }
        public bool HarRåd(int pris, int råd)
        {
            if(råd >=pris)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        */
    }
}
