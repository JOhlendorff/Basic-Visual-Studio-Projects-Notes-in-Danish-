﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bøger_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Bog sherlockHolmes = new Bog(21);
            sherlockHolmes.SetTitle("Spergasus");
            Bog mobySticks = new Bog(21, "Moby Sticks");
            Bog hi = new Bog(23);
            /*sherlockHolmes.PrintInfo();
            bool råd = sherlockHolmes.HarRåd(150, 151);
            if(råd == true)
                Console.WriteLine("Du har råd");
            else
                Console.WriteLine("Du har ikke råd");
            */
            /*sherlockHolmes.SetPris(155);//Denne metode sætter integralet "pris" i class Bog til at være 150
            sherlockHolmes.SetTitle("Moby's Dicks");//Denne metode sætter stringen "title" i class bog til at være "Moby's Dicks"
            Console.WriteLine(sherlockHolmes.GetTitle() + " koster - " + sherlockHolmes.GetPris());//Denne cw udskrive string og int fra class Bog, med objektet der kalder metoderne der "getter" dem
    */      sherlockHolmes.PrintInfo2();
            mobySticks.PrintInfo2();
            hi.PrintInfo2();
            Console.ReadKey();
        }
    }
}
