﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Referencer_opgave
{
    class Bog
    {
        private string favoriteBog;
        public void SetFavoriteBog(string favoriteBog)
        {
            this.favoriteBog = favoriteBog;
        }
        public string GetFavoriteBog()
        {
            return favoriteBog;
        }
        public void PrintInfo()
        {
            Console.WriteLine(favoriteBog);
        }
    }
}
