﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Referencer_opgave
{
    class Program
    {
        static void Main(string[] args)
        {
            Person jens = new Person();// laver et nyt person objekt
            Bog favoriteBog = new Bog();// laver en ny bog 
            favoriteBog.SetFavoriteBog("Karl Marx' Communist Manifesto");//giver en string til bog objektet, der indeholder navnet jeg vil udskrive
            jens.SetBog(favoriteBog);//Overfører favoriteBog til referenceobjektet i person classen
            jens.SetAlder(21);//Udfylder instansvariablerne i person classen
            jens.SetNavn("Jens");
            jens.SetPenge(0);
            jens.PrintInfo();//udfører cw metoden i person der udskriver de instansvariabler jeg har angivet i program classen
            jens.PrintBookInfo();
            favoriteBog.PrintInfo();//For at tjekke om objektet jeg refererer person klassen til eksisterer. Man kan også lave en if_ else i person til at gøre det.
            Console.ReadKey();

        }
    }
}
