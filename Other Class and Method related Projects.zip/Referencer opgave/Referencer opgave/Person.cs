﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Referencer_opgave
{
    class Person
    {
        Bog favoriteBog;
        public void SetBog(Bog favoriteBog)
        {
            this.favoriteBog = favoriteBog;
        }
        public Bog GetBog()
        {
            return favoriteBog;
        }
        private string navn;
        private int alder;
        private double penge;
        public void SetNavn(string navn)
        {
            this.navn = navn;
        }
        public void SetAlder(int alder)
        {
            this.alder = alder;
        }
        public void SetPenge(int penge)
        {
            this.penge = penge;
        }
        public string GetNavn()
        {
            return navn;
        }
        public int GetAlder()
        {
            return alder;
        }
        public double GetPenge()
        {
            return penge;
        }
        public void PrintInfo()
        {
            Console.WriteLine(navn+" er "+alder+" år og har " +penge+ " kr ");
        }
        public void PrintBookInfo()
        {
            Console.WriteLine(navn+"'s favorit bog er "+favoriteBog.GetFavoriteBog());
        }
        
    }
}
