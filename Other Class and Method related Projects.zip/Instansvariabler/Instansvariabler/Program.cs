﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Instansvariabler
{
    class Bog
    {
        private int pris;
        private string title;
        public void PrintInfo()
        {
            Console.WriteLine("Jeg er en bog");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Bog sherlockHolmes = new Bog();
            sherlockHolmes.PrintInfo();
            Console.ReadKey();
        }
    }
}