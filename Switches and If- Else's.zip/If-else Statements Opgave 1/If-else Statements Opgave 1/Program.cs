﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace If_else_Statements_Opgave_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int tal1 = 42, tal2 = 64, result = tal1 + tal2;
            if (result > 100)//Denne if gør at hvis resultatet er større end 100 den udskriver den writelinen nedenunder 
            {
                Console.WriteLine("Summen er større end 100!");
            }
            else if (result < 100)//Denne if gør at hvis resultatet er mindre end 100 udskriver den writelinen nedenunder
            {
                Console.WriteLine("Summen er mindre end 100");
            }
            else//Eftersom den sidste mulighed er at tallet er 100 behøver man ikke lave flere else ifs
            {
                Console.WriteLine("Summen er 100");
            }
            Console.ReadKey();
            //Eftersom resultatet bliver 106 er det den første if der bliver vist
        
            

            
        }
    }
}
