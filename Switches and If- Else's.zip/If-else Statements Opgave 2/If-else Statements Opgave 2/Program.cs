﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace If_else_Statements_Opgave_2
{
    class Program
    {
        static void Main(string[] args)
        {

            string Alder;
            int AlderC;
            Console.WriteLine("Indtast din alder");
            Alder = Console.ReadLine();
            AlderC = Convert.ToInt32(Alder);
            if (AlderC > 57)// Denne if træder i kraft hvis AlderC er større end 57
            {
                Console.WriteLine("Du er for gammel");
            }
            else//Eftersom alderen kun kan være mindre eller lig med 57 hvis ikke de er over 57 udskriver den det nedenunder
            {
                Console.WriteLine("Du er ikke for gammel");
            }
            Console.ReadKey();
        }
    }
}
