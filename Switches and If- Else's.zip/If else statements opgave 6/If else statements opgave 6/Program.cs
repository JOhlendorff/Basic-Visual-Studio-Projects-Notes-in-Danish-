﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace If_else_statements_opgave_6
{
    class Program
    {
        static void Main(string[] args)
        {
            string Km;
            double KmC, Fradrag;
            Console.WriteLine("Indtast antal dagligt kørte Kilometer");
            Km = Console.ReadLine();
            KmC = Convert.ToDouble(Km);//Konverterer til en double fordi der regnes med decimaler i opgaven
            if(KmC <= 24)
            {
                Console.WriteLine("Du får ikke noget fradrag");
            }
            else if (KmC >24 && KmC <121)// Hvis KmC er over 24 og under 121 gives der 1.93 kr per km
            {
                Fradrag = (KmC - 24) * 1.93;
                Console.WriteLine("Dit fradrag er {0} kr.", Fradrag);
            }
            else if(KmC >= 121)// Jeg kunne have lavet en else her, men gjorde det ikke fordi jeg først kom i tanke om at den forrige else if også var under 121 efter jeg havde skrevet den sidste
            {
                Fradrag = 96 * 1.93 + (KmC - 120) * 0.97;
                Console.WriteLine("Dit fradrag er {0} kr.", Fradrag);
            }
            Console.ReadLine();

        }
    }
}
