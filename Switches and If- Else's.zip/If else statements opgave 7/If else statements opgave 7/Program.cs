﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace If_else_statements_opgave_7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Indtast en værdi mellem 1-6");
            string TalValg = Console.ReadLine();
            int TalValgC = Convert.ToInt32(TalValg);
            Console.WriteLine("Vælg baggrundsfarve, blå, gul, rød eller grøn");
            string Farve = Console.ReadLine();
            if(TalValgC < 4 || TalValgC >4 && TalValgC <= 6) //Hvis tallet der er valgt er mindre end 4, større end 4 og mindre end 6 udskriver den det nedenunder
            {
                Console.WriteLine("Du har tastet tallet {0}", TalValgC);
                Console.ReadKey();
            }
            else if(TalValgC == 4) //Hvis tallet er præcis 4 udskriver den det nedenunder
            {
                Console.ForegroundColor = ConsoleColor.White; //Vælger at skriften skal være hvid
                Console.SetCursorPosition(4,7);
                if(Farve == "grøn")
                {
                    Console.BackgroundColor = ConsoleColor.Green;//Sætter konsollens baggrundsfarve til at være grøn
                    
                }
                else if(Farve == "rød")
                {
                    Console.BackgroundColor = ConsoleColor.Red;
                }
                else if(Farve == "blå")
                {
                    Console.BackgroundColor = ConsoleColor.Blue;
                }
                else if(Farve == "gul")
                {
                    Console.BackgroundColor = ConsoleColor.Yellow;
                }
                Console.Clear();//Der sættes en clear for at fjerne konsollens forrige baggrundsfarve (sort) og gør den til brugerens valgte farve
                Console.WriteLine("Tillykke du har vundet");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Du har tastet forkert, tallet skal være mellem 1 og 6");
                System.Threading.Thread.Sleep(10000); //Denne funktion gør at systemet lukker efter 10000 milisek. Den kan også gøre andet, men eftersom det er den sidste linje i koden i denne else if lukker den programmet.

            }
            
        }
    }
}
