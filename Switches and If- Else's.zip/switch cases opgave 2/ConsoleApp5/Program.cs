﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Program
    {
        static void Main(string[] args)
        {
            string Drinkvalg;
            int[] Pris = { 21, 22, 23, 33, 44, 42 }; // Jeg har lavet et array der indeholder priserne på hver drink. Hvert udtryk i arrayet præsenteres med et nummer når man henviser til noget specifikt i arrayet 
            Console.WriteLine("Vælg en drink");
            Console.WriteLine("1. Isbjørn");
            Console.WriteLine("2. Champagnebrus");
            Console.WriteLine("3. Tequila Sunrise");
            Console.WriteLine("4. Mojito");
            Console.WriteLine("5. Brandbil");
            Console.WriteLine("6. Filur");
            Drinkvalg = Console.ReadLine();
            switch(Drinkvalg)
            {
                case "1": // Jeg kunne have lavet flere cases hvor det f.eks. ville være muligt at skrive Isbjørn i stedet for 1, men opstilte det som det så ud i opgaven, nummereret
                    {
                        Console.WriteLine("Du har valgt Isbjørn som koster {0}", Pris[1]); //Henviser til plads 1 i arrayet
                        break;
                    }
                case "2":
                    {
                        Console.WriteLine("Du har valgt Champagnebrus som koster {0}", Pris[2]);
                        break;
                    }
                case "3":
                    {
                        Console.WriteLine("Du har valgt Tequila Sunrise som koster {0}", Pris[3]);
                        break;
                    }
                case "4":
                    {
                        Console.WriteLine("Du har valgt Mojito som koster {0}", Pris[4]);
                        break;
                    }
                case "5":
                    {
                        Console.WriteLine("Du har valgt Brandbil som koster {0}", Pris[5]);
                        break;
                    }
                case "6":
                    {
                        Console.WriteLine("Du har valgt Filur som koster {0}", Pris[6]);
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Du har valgt noget forkert");
                        break;
                    }
                    
                
            }
            Console.ReadKey();

        }
    }
}
