﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace If_else_statements_opgave_5
{
    class Program
    {
        static void Main(string[] args)
        {
            string Brugernavn = "Admin", BrugernavnF, Password = "Password", PasswordF, Navn;//Erklærer variabler, kom i tanke om at jeg ikke behøvede strings til Password og Brugernavn eftersom jeg kunne have lavet en if(Brugernavn == "Admin" && Password == "Password") i stedet for strings
            Console.WriteLine("Indtast dit navn");
            Navn = Console.ReadLine();// Henter brugerens input
            Console.WriteLine("Indtast Brugernavn");
            BrugernavnF = Console.ReadLine();
            if(BrugernavnF == Brugernavn)
            {
                Console.WriteLine("Indtast password");
            }
            else
            {
                Console.WriteLine("Brugernavnet er forkert");
            }
            PasswordF = Console.ReadLine();// Jeg bruger både denne string til at forhindre programmet i at lukke for brugeren der har tastet forkert og til at fange password
            if (BrugernavnF == Brugernavn && PasswordF == Password)// Hvis brugernavnet og passwordet matcher det jeg har angivet i variablerne skriver programmet velkommen
            {
                Console.WriteLine("Velkommen, {0}", Navn);// Udskriver variablen som brugeren erklærede 
                Console.ReadKey();
            }
            else if(BrugernavnF !=Brugernavn)// Eftersom jeg ikke har lyst til at afvise brugeren 2 gange hvis han har indtastet forkert brugernavn, laver jeg endnu en if der gør at hvis han har skrevet det forkerte brugernavn bliver han ikke spurgt om password
            {// != betyder ikke lig med

            }
            else
            {
                Console.WriteLine("Password er forkert");// Enten er password korrekt eller også er det forkert. Derfor virker en else
            }
            //Console.ReadKey();
        }
    }
}
