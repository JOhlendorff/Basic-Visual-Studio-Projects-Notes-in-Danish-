﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace If_else_statements_opgave_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Indtast din alder");
            string Alder = Console.ReadLine();
            int AlderC = Convert.ToInt32(Alder);
            if(AlderC >= 50 && AlderC <=60) //Statementet gør at hvis AlderC er imellem og med 50 og 60 vil den udskrive det der står nedenunder
            {//Jeg har taget 50 og 60 med eftersom opgaven siger hvis brugeren er over 60 skal den udskrive "du er for gammel", eftersom 50 ikke er over 60 er jeg nødt til at sige 50<= fordi ellers ville koden ikke virke selvom opgaven ikke implicit siger jeg skal gøre det
                Console.WriteLine("Du er hverken for gammel eller for ung");
            }
            else if(AlderC < 50) // Hvis brugeren er under 50 udskriver den dette
            {
                Console.WriteLine("Du er for ung");
            }
            else // Eftersom det sidste mulige er at alder kun kan være over 60 behøver jeg kun lave en else
            {
                Console.WriteLine("Du er for gammel");
            }
            Console.ReadKey();
            

            
        }
    }
}
