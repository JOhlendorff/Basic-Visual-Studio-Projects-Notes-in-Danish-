﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace switch_cases_opgave_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string Valg, Farve;
            Console.WriteLine("Vælg en farve");
            Farve = Console.ReadLine();
            Console.WriteLine("Indtast et tal mellem 1 og 6");
            Valg = Console.ReadLine();
            switch(Valg)
            {
                case "1":
                {
                        Console.WriteLine("Du har valgt tallet {0}",Valg);
                        break;// Der bruges en break til at afslutte en case i en switch

                }
                case "2":
                    {
                        Console.WriteLine("Du har valgt tallet {0}", Valg);
                        break;
                    }
                case "3":
                    {
                        Console.WriteLine("Du har valgt tallet {0}", Valg);
                        break;
                    }
                case "4":
                    {
                        if (Farve == "grøn") 
                        {
                            Console.BackgroundColor = ConsoleColor.Green;
                        }
                        else if (Farve == "rød") 
                        {
                            Console.BackgroundColor = ConsoleColor.Red;
                        }
                        else if (Farve == "blå")
                        {
                            Console.BackgroundColor = ConsoleColor.Blue;
                        }
                        else if (Farve == "gul")
                        {
                            Console.BackgroundColor = ConsoleColor.Yellow;
                        }
                        Console.Clear();
                        Console.SetCursorPosition(10, 10);
                        Console.WriteLine("Tillykke Du har vundet");
                        break;
                        
                    }
               case "5":
                    {
                        Console.WriteLine("Du har valgt tallet {0}", Valg);
                        break;
                    }
                case "6":
                    {
                        Console.WriteLine("Du har valgt tallet {0}", Valg);
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Du har tastet forkert. Tallet skal være mellem 1 og 6");
                        System.Threading.Thread.Sleep(10000);//Får systemet til at vente 10000 milisek 
                        Environment.Exit(-1);//Eftersom programmet skal slukke hvis personen vælger forkert skal vi ikke have reakeyen med udenfor switchen. Så i stedet for at lægge en readkey i hver case har jeg lavet en funktion der lukker programmet indenfor denne case, og lavet en readkey udenfor selve switchen
                        break;
                    }

            }
            Console.ReadKey();
        }
    }
}
