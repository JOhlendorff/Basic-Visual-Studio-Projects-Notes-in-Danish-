﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aritmetiske_Udtryk_Opgave
{
    class Program
    {
        static void Main(string[] args)
        {
            int Resultat1 = 2+1*2, Resultat2 = (2+1) * 2, Resultat3 = 5 / 2, Resultat4 = 8 % 3, Resultat5 = 1 - 5; //Opgaven går ud på at vise forskellige aritmetiske udtryk med programmer. Jeg har opdelt hvert regnestykke med en console.clear for at gøre det mere overskueligt. Jeg har sat readkeys så den ikke clearer før man har set resultatet.
            Console.WriteLine(Resultat1);
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine(Resultat2);
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine(Resultat3);
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine(Resultat4);
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine(Resultat5);
            Console.ReadKey();
            
           
        }
    }
}
