﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variabler_i_Udtryk_Opgave_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int Tal1 = 2, Tal2 = 3, Tal3 = 4, Resultat;
            Resultat = Tal1 + Tal2 - Tal3; // resultatet erklæres ved et regnestykke hvor alle de andre variabler indgår
            Console.WriteLine(Resultat);
            Console.ReadKey();
        }
    }
}
