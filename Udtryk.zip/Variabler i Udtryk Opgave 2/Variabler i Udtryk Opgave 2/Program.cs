﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variabler_i_Udtryk_Opgave_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int Tal1 = 12;
            double Tal2 = 13, Tal3 = 33, Resultat;
            Resultat = Tal1 + 5 - Tal2 * 30 / Tal3; // Denne opgave kræver at man laver et program der udregner et regnestykke med aritmetiske udtryk som den forrige opgave, bortset fra at man skal "mikse" tal ind i udtrykket
            Console.WriteLine(Resultat);
            Console.ReadKey();

        }
    }
}
