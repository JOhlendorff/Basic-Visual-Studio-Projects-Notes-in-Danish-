﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace If_else_portfolio
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Festen";
            Console.WriteLine("Hvilken farve foretrækker du? Rød, grøn  blå eller gul? ");
            string farve = Console.ReadLine(); //baggrundsfarve defineres af brugeren her
            Console.WriteLine("Hvor gammel er du?");
            string alder = Console.ReadLine();// brugerens alder defineres af brugeren her
            int alderc = Convert.ToInt32(alder);
            if (farve == "grøn")
            {
                Console.BackgroundColor = ConsoleColor.Green;
            }
            else if (farve == "blå")
            {
                Console.BackgroundColor = ConsoleColor.Blue;
            }
            else if (farve == "rød")
            {
                Console.BackgroundColor = ConsoleColor.Red;
            }
            else if (farve == "gul")
            {
                Console.BackgroundColor = ConsoleColor.Yellow;
            }
            Console.Clear();
            if(alderc >= 18) // hvis alder er over eller = 18 skrives dette
            {
                Console.WriteLine("Velkommen til cocktailbaren");
            }
            else// hvis alder er alt andet end over eller  = 18 skrives dette
            {
                Console.WriteLine("Velkommen til sodavandsbaren");
            }
            Console.ReadKey();
        }
    }
}
