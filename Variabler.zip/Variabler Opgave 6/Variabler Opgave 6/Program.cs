﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variabler_Opgave_6
{
    class Program
    {
        static void Main(string[] args)
        {
            string radius;
            double Pi = Math.PI, Areal, RadiusC;
            Console.WriteLine("Indtast radius af cirkel");
            radius = Console.ReadLine();
            RadiusC = Convert.ToDouble(radius);
            Areal = Pi * Math.Pow(RadiusC, 2);
            Console.WriteLine("Din cirkel er {0} i areal",Areal);
            Console.ReadKey();
            

        }
    }
}
