﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variabler___Opgave_4
{
    class Program
    {
        static void Main(string[] args)
        {
            string Navn;
            string alder;
            Console.WriteLine("Indtast dit navn");
            Navn = Console.ReadLine();
            Console.WriteLine("Indtast din alder");
            alder = Console.ReadLine();
            Console.WriteLine("Du hedder {0} og er {1} år gammel", Navn, alder);
            Console.ReadKey();
        }
    }
}
