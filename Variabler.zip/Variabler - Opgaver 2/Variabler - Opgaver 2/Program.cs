﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variabler___Opgaver_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int tal1 = 5, tal2 = 3;
            Console.WriteLine("Tal1 er {0}", tal1);
            Console.WriteLine("Tal2 er {0}", tal2);
            Console.ReadKey();
        }
    }
}
