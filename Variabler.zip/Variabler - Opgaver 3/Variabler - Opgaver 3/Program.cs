﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variabler___Opgaver_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string Navn = "Søren";
            int Alder = 16;
            double Penge = 1234.34;
            Console.WriteLine("Jeg hedder {0}, er {1} og har tjent {2} kr. på at lappe cykel", Navn, Alder, Penge);
            Console.ReadKey();
        }
    }
}
