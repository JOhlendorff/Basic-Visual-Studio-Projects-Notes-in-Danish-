﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variabler___Opgaver_4
{
    class Program
    {
        static void Main(string[] args)
        {
            double Kage = 23.56, Øl = 34.67, Pølse = 65.34;
            Console.WriteLine("Kage     {0}",Kage);
            Console.WriteLine("Øl       {0}",Øl);
            Console.WriteLine("Pølse    {0}",Pølse);
            Console.WriteLine("I alt    Beregnes");
            Console.ReadKey();
        }
    }
}
