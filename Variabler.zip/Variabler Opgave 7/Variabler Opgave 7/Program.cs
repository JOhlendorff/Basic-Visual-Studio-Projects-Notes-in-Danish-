﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variabler_Opgave_7
{
    class Program
    {
        static void Main(string[] args)
        {
            string Tal1, Tal2, Tal3; //Der laves en string for hvert tal, eftersom strings bruges til at opfange brugerens input. 
            double Tal1C, Tal2C, Tal3C; //Disse doubles hedder noget med C for at hjælpe mig med at holde styr på hvilke tal der er convertet. De er doubles fordi det lader brugeren indtaste tal der kan give et resultat med decimaler
            double Avg, Sum;
            Console.WriteLine("Dette program vil udregne sum og gennemsnit af 3 tal du indtaster");
            Console.WriteLine();
            Console.WriteLine("Indtast første tal");
            Tal1 = Console.ReadLine();
            Tal1C = Convert.ToDouble(Tal1); //Denne funktion konverterer stringen der blev opfanget af readlinen før. Som man kan se bliver doublen defineret af denne linje
            Console.WriteLine();
            Console.WriteLine("Indtast andet tal");
            Tal2 = Console.ReadLine();
            Tal2C = Convert.ToDouble(Tal2);
            Console.WriteLine();
            Console.WriteLine("Indtast tredje tal");
            Tal3 = Console.ReadLine();
            Tal3C = Convert.ToDouble(Tal3);
            Sum = Tal1C + Tal2C + Tal3C; //Denne funktion udregner summen af de konverterede tal brugeren indtastede
            Avg = Sum / 3;//Denne funktion udregner gennemsnittet af brugerens tal
            Console.WriteLine();
            Console.WriteLine("Summen af tallene du har indtastet er {0}",Sum); //Jeg angiver at writelinen skal bruge sum på nullets plads
            Console.WriteLine();
            Console.WriteLine("Gennemsnittet af tallene du har tastet er {0}",Avg);
            Console.ReadKey();

        }
    }
}
