﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strings_Opgave_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string Dato = "Idag har vi datoen den 8. november";
            Console.WriteLine(Dato); // Udskriver stringen
            Console.ReadKey();
            
        }
    }
}
