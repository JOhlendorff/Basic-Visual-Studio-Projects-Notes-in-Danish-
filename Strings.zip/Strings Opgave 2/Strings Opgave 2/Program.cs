﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strings_Opgave_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int Heltal = 1; //Viser at int er til heltal
            string Tekst = "Tekst"; // String er til tekst
            double Deca = 0.1; // Doubles er til decimaler
            Heltal = 2; //Hvis man ændrer definitionen på variablen udskrives den som det seneste skrevet
            Console.WriteLine(Heltal);
            Console.WriteLine(Tekst);
            Console.WriteLine(Deca);
            Console.ReadKey();

        }
    }
    }
}
