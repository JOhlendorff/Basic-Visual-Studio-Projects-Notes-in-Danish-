﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strings_Opgave_4
{
    class Program
    {
        static void Main(string[] args)
        {
            double Penge = 200.50;
            string Hvem = "Jeg har", Hvor = "kr. i banken";
            Console.WriteLine("{0} {1} {2}", Hvem, Penge, Hvor); // Curly brackets angiver variablernes position
            Console.ReadKey();
        }
    }
}
