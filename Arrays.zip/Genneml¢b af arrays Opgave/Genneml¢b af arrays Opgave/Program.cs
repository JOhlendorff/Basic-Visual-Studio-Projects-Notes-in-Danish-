﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gennemløb_af_arrays_Opgave
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = { 80, 90, 100, 110, 120, 130 };
            for (int tæller = 0, sum = 0, arraySum = array.Sum(); sum <= arraySum; sum += array[tæller++])// tæller fortæller både hvilket indeks der er valgt til arrayet, og om hvert tal fra arrayet er lagt til i loopen, eftersom loopen stopper efter tæller når arrayets længde
            {
                Console.WriteLine(sum);
                if (tæller == array.Length)
                {
                    break;
                }
            }
            Console.ReadKey();
        }
    }
}
