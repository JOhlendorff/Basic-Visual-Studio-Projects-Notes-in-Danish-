﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays_Opgave
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = { -2, -1, 0, 10 };//Laver en samling af ints. indeks for første tal er [0], sidste tal er [3]
            Console.WriteLine("{0} {1}", array[1], array[3]);
            Console.WriteLine(array.Sum());//Lægger tallene i arrayet sammen
            Console.ReadKey();

        }
    }
}
